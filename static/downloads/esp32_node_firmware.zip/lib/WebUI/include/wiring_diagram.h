#ifndef WIRING_DIAGRAM_H
#define WIRING_DIAGRAM_H

// Declare the external HTML content that is defined in main.cpp
extern const char* WIRING_DIAGRAM_HTML;

#endif // WIRING_DIAGRAM_H