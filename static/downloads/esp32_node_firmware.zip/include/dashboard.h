#ifndef DASHBOARD_H
#define DASHBOARD_H

// Declare the external HTML content that is defined in main.cpp
extern const char* DASHBOARD_HTML;

#endif // DASHBOARD_H