#ifndef WIRING_DIAGRAM_H
#define WIRING_DIAGRAM_H

// Declare the external HTML content that is defined in main.cpp
extern const char* WIRING_DIAGRAM_HTML;
/* Actual content is defined in main.cpp to prevent HTML parsing issues in .h files */

#endif // WIRING_DIAGRAM_H