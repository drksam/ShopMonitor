from flask import Flask, request, jsonify
import time
import json

app = Flask(__name__)

# File to store users
USER_FILE = 'users.json'

# Function to load users from file
def load_users():
    try:
        with open(USER_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Function to save users to file
def save_users():
    with open(USER_FILE, 'w') as f:
        json.dump(users, f)

# Load users when the server starts
users = load_users()

manager_code = "1234"  # Example manager code, can be stored more securely

# Log events
def log_event(event):
    with open("activity_log.txt", "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {event}\n")

@app.route('/')
def home():
    return "Welcome to the RFID System"

@app.route('/check_user')
def check_user():
    rfid = request.args.get('rfid')
    machine_id = request.args.get('machine_id')
    if rfid in users and users[rfid]["access"]:
        if not users[rfid]["logged_in"]:
            users[rfid]["logged_in"] = True
            users[rfid]["last_login"] = time.time()
            log_event(f"User {users[rfid]['name']} (RFID: {rfid}) logged in on machine {machine_id}.")
            save_users()
            return "ALLOW"
        else:
            return "LOGOUT"
    else:
        return "DENY"

# New logout endpoint
@app.route('/logout')
def logout_user():
    rfid = request.args.get('rfid')
    machine_id = request.args.get('machine_id')

    if rfid in users:
        if users[rfid]["logged_in"]:
            users[rfid]["logged_in"] = False
            users[rfid]["last_login"] = None
            log_event(f"User {users[rfid]['name']} (RFID: {rfid}) logged out from machine {machine_id}.")
            save_users()
            return "LOGOUT"
        else:
            return "User not logged in", 400
    else:
        return "User not found", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)
